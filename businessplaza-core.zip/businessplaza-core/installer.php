<?php  
/**
 * Do stuff when plugin activates
 */
