;(function($) {
    "use strict";

    console.log('From Admin Js')
})(jQuery);