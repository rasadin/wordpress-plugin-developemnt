<?php 
namespace WPPB\Admin\Modules\HelloWorld;

class HelloWorld {
    /**
     * Construct Class
     * @author Rabiul
     * @since 1.0.0
     */
    public function __construct() {
        // echo 'Hello Module';
    }
}