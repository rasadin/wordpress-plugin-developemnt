<?php 
/**
 * =============================================
 * Helper Functions
 * @author Rabiul
 * @since 1.0.0
 * =============================================
 */

function just_die() {
    wp_die('Died from helpers');
}